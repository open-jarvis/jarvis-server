# Jarvis Server

Jarvis backend and which handles incoming data from mobile phones and smart devices


## Installation
```bash
git clone https://github.com/open-jarvis/jarvis-server
cd jarvis-service
python3 jarvisd.py --install
# launch installer script
# and follow the instructions
```

